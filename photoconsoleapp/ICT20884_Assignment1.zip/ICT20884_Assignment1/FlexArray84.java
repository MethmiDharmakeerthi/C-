/**
 * Name: HDTN Madhusanka
 * Index: ICT/20/884
 * Assignment: Assignment 1
 * Module: ITC 2212 Data Structures and Algorithms
 */

public class FlexArray84 {
    public int[] arr = new int[10];     // array that stores the values

    public void insert84(int value) {
        int i;
        for (i = 0; i < arr.length; i++) {
            if (arr[i] == 0)            // if element is empty
            {
                arr[i] = value;
                return;                 // stop the loop, after entering the value
            }
        }

        // if array is full
        if (i == arr.length)            // Checks if the value of i has reached the end
        {
            System.out.println("Array is full. Cannot add another element.");
        }
    }

    public void deleteByIndex84(int index) {
        arr[index] = 0;
    }

    public void deleteByValue84(int value) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == value) {
                arr[i] = 0;
            }
        }
    }

    public void update84(int value, int index) {
        arr[index] = value;
    }

    public void display84() {
        for (int i : arr) {
            System.out.print(i + "\t");
        }
    }

    public void sortAsd84() {
        // insertion sort
        int in, out;
        for(out = 1; out < arr.length; out++) // out is dividing line
        {
            int temp = arr[out];        // remove marked item
            in = out;                   // start shifts at out
            while(in > 0 && arr[in - 1] >= temp) // until one is smaller,
            {
                arr[in] = arr[in - 1];  // shift item right,
                --in;                   // go left one position
            }
            arr[in] = temp;             // insert marked item
        }
    }

    public void sortDes84() {
        // insertion sort
        int in, out;
        for (out = 1; out < arr.length; out++) // out is dividing line
        {
            int temp = arr[out];        // remove marked item
            in = out;                   // start shifts at out

            while (in > 0 && arr[in - 1] < temp) // until one is smaller,
            {
                arr[in] = arr[in - 1];  // shift item right,
                --in;                   // go left one position
            }
            arr[in] = temp;             // insert marked item
        }
    }

    public int search84(int searchKey) {
        // Binary Search
        int lowerBound = 0;
        int upperBound = arr.length - 1;
        int mid;
        while (true) {
            mid = (lowerBound + upperBound ) / 2;
            if (arr[mid] == searchKey) return mid; // found it
            else if (lowerBound > upperBound) return -1; // can’t find it
            else // divide range
            {
                if (arr[mid] < searchKey) lowerBound = mid + 1; // it’s in upper half
                else upperBound = mid - 1; // it’s in lower half
            }
        }
    }
}
